"""
IMPORT LIBRARIES
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
import os
from tqdm import tqdm

"""
PRODUCE THE PLOTS FOR ALL DATASETS. Ctrl + F "ADJUST THIS" to find the parts that you need to customize to your needs!
"""
# Get the list of all file names in the directory
directory = './'  # Replace with the path to your directory
file_names = os.listdir(directory)
output_directory = './Plots/'

# Make the output directory in case it does not exist
if not os.path.exists(output_directory):
        os.makedirs(output_directory)
        print(f"Directory '{output_directory}' created successfully.")
else:
    print(f"Directory '{output_directory}' already exists.")

# Set the lists to iterate over
# ADJUST THIS TO YOUR FILE NAME NEEDS!!
participant_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13] # 13 participants
# participant_numbers = ["namrata"] # 5 participants
finger_numbers = [0] # One finger
graph_names = ['_training_sales_ads', '_training_social_media', 
               '_testing_property_distance', '_testing_income_work_hours',
               '_testing_views_subscribers', '_testing_scores_attendance']
file_extension = '.csv'

# Set the font sizes for the plots
fontsize_title = 20
fontsize_axis = 15
fontsize_ticks = 15
fontsize_legend = 15

# Set the max number of pixels in each axis for your tablet
# ADJUST THIS TO YOUR TABLET!
maxX = 2560 # Pixels
maxY = 1600 # Pixels

# Prepare file where missing data will be listed
missing_data_file_path = "./missing_data.txt"
with open(missing_data_file_path, "w") as file:
    file.write("This file contains a list of all the LDV data that is either missing or still needs to be taken. If empty, it means that no data is missing:\n\n")

for participant_number in tqdm(participant_numbers):
    for graph_name in graph_names:
        for finger in finger_numbers:
            # Obtain the file name
            file_name = str(participant_number) + graph_name + file_extension
            
            # # Try to find the file and produce the plots
            try:
                # Import the dataframe
                df = pd.read_csv(file_name, sep = ",")

                # Only keep rows where there are fingers on screen!
                # Drop rows where values in Columns X and Y are zero
                # ADJUST THIS TO THE AMOUNT OF FINGERS YOU ARE TRACKING!! (one XY pair per finger)
                df_filtered = df.drop(df.loc[(df['x0'] == 0) &
                                             (df['y0'] == 0)].index)

                # Reset the index of the filtered DataFrame
                df_filtered.reset_index(drop=True, inplace=True)

                ########################################################################
                # Produce the Time-wise Scatterplot
                ########################################################################
                # Clear any previous figure
                plt.clf()
                
                # Set the min and max for the exploration time colorbar
                order = np.linspace(0, 100, len(df_filtered))                
                
                # Set the plot background color
                ax = plt.axes()
                # Setting the background color of the plot
                ax.set_facecolor('#440154')

                # Create the scatter plot
                plt.scatter(df_filtered['x' + str(finger)], df_filtered['y' + str(finger)], c=order, cmap='viridis')
                plt.gca().invert_yaxis()
                # Get the current X-axis object
                x_axis = plt.gca().xaxis
                
                # Move the X-axis to the top
                x_axis.set_ticks_position('top')
                x_axis.set_label_position('top')

                # ADJUST THIS TO YOUR TITLE AND FILE NAME NEEDS!!
                # Set the title of the plot
                title_header = "Exploration Strategy"
                if "sales_ads" in file_name.replace('.csv', ""):
                    title_content = "Sales Profit vs Advertising Budget"
                elif "social_media" in file_name.replace('.csv', ""):
                    title_content = "Shares vs Likes"
                elif "property_distance" in file_name.replace('.csv', ""):
                    title_content = "Property Price vs Distance"
                elif "income_work_hours" in file_name.replace('.csv', ""):
                    title_content = "Yearly Income vs Work Hours"
                elif "views_subscribers" in file_name.replace('.csv', ""):
                    title_content = "Views vs Subscribers"
                elif "scores_attendance" in file_name.replace('.csv', ""):
                    title_content = "Test Scores vs Class Attendance"
                title_participant_number = file_name.replace('.csv', "")[0] # The first character of the string
                title_finger_number = str(finger + 1)
                plot_title = (title_header + ": " + 
                            title_content + ", " + 
                            "Participant " + str(title_participant_number) + ", " +
                            "Finger " + str(title_finger_number))
                plt.title(plot_title, size = fontsize_title)
                
                # Set the name and font size of the X axis
                plt.xlabel("X [px]", size = fontsize_axis)
                plt.xticks(fontsize = fontsize_ticks)
                
                # Set the name and font size of the Y axis
                plt.ylabel("Y [px]", size = fontsize_axis)
                plt.yticks(fontsize = fontsize_ticks)
                
                # Add a colorbar with labels and set its title and font size
                cbar = plt.colorbar(shrink = 1.0)
                cbar.set_label('Exploration Time %', fontsize = fontsize_legend)
                cbar.ax.tick_params(labelsize=fontsize_ticks) 
                
                # Set the figure size in inches, keeping the same ratio as the real-life table
                fig = plt.gcf()
                base_size = 10 # inches
                fig.set_size_inches(base_size, base_size*maxY/maxX)
                                
                # Show the plot
                fig.savefig(output_directory + file_name.replace('.csv', '') + 
                            '_scatter_f' + str(finger), 
                            bbox_inches='tight')

            # ELSE
            except Exception:
                # print("Error when processing file: " + file_name)
                # If the file is missing, then write its name to the missing_data_log file ONCE
                if finger == finger_numbers[0]:
                    with open(missing_data_file_path, "a") as file:
                        file.write(file_name + "\n")
                pass

